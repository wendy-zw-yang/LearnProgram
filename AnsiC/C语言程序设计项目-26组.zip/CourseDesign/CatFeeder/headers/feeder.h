/*
Author: 郑世婷
*/
#ifndef FEEDER_HEADER_FILE
#define FEEDER_HEADER_FILE

void manualFeed(CatList *list);
void autoFeed(CatList *list);

#endif
